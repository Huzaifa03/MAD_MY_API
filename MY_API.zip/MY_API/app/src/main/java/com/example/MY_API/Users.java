
package com.example.MY_API;

import java.util.List;

public class Users {

    private List<Single_User> users = null;

    public List<Single_User> getUsers() {
        return users;
    }

    public void setUsers(List<Single_User> users) {
        this.users = users;
    }

}
