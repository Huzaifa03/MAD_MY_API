
package com.example.MY_API;


public class Single_User {

    private String ID;
    private String Name;
    private String Email_ID;
    private String Gender;
    private Contact contact;

    public String getID() {
        return ID;
    }

    public void setId(String ID) {
        this.ID = ID;
    }

    public String getName() {
        return Name;
    }

    public void setName(String Name) {
        this.Name = Name;
    }

    public String getEmail_ID() {
        return Email_ID;
    }

    public void setEmail(String Email_ID) {
        this.Email_ID = Email_ID;
    }

    public String getGender() {
        return Gender;
    }

    public void setGender(String Gender) {
        this.Gender = Gender;
    }

    public Contact getContact() {
        return contact;
    }

    public void setContact(Contact contact) {
        this.contact = contact;
    }

}
