package com.example.MY_API;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.util.Log;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.VolleyLog;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;
import com.bumptech.glide.Glide;
import com.google.gson.Gson;

import org.json.JSONException;
import org.json.JSONObject;

public class MainActivity extends AppCompatActivity {

    TextView Text_View;
    ProgressBar Progress_Bar;
    ImageView Image_View;
    RequestQueue queue;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Text_View = findViewById(R.id.Text_View);
        Progress_Bar = findViewById(R.id.Progress_Bar);
        Image_View = findViewById(R.id.Image_View);

        Glide.with(this).load("https://i.pinimg.com/280x280_RS/69/11/99/69119997f8e502169a5b576fbf99f613.jpg").into(imageView);


        queue = Volley.newRequestQueue(this);
        fetchJsonResponse();


        Thread thread = new Thread(new Runnable() {
            @Override
            public void run() {
                int counter = 1;
                while (counter <=100) {

                    final int finalCount = counter;
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            textView.setText(finalCount + " ");
                            progressBar.setProgress(finalCount);
                        }
                    });

                    try {
                        Thread.sleep(500);
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }
                    counter++;
                }

            }
        });

        thread.start();

    }

    private void fetchJsonResponse() {
        // Pass second argument as "null" for GET requests
        Response.Listener<JSONObject> responseListener = new Response.Listener<JSONObject>() {
            @Override
            public void onResponse(JSONObject response) {

                Gson gson = new Gson();
                Users users = gson.fromJson(response.toString(),Users.class);
                Log.i("Faisal", "onResponse: "+users.getUsers().get(1).getName());

                Log.i("Faisal", "onResponse: " + response.toString());
            }
        };
        Response.ErrorListener errorListener = new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Log.e("Faisal", "onErrorResponse: " + error.getMessage());
            }
        };
        JsonObjectRequest req = new JsonObjectRequest(Request.Method.GET, "https://run.mocky.io/v3/354ca8db-7838-4548-8f23-c16443a5c4b7", null,
                responseListener, errorListener);

        /* Add your Requests to the RequestQueue to execute */
        queue.add(req);
    }
}